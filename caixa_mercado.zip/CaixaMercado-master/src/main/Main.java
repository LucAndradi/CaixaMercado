
package main;

import View.TelaCaixa;


public class Main {

    
    public static void main(String[] args) {
        new TelaCaixa().setVisible(true);
    }
    
}
