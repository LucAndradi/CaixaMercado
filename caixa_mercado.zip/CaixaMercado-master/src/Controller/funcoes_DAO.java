/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import View.TelaCaixa;
import static View.TelaCaixa.nome_t;
import static View.TelaCaixa.prec_txt;
import static View.TelaCaixa.prod_txt;
import static View.TelaCaixa.quan;
import static View.TelaCaixa.txtCod;
import static View.TelaCaixa.txtPreco2;
import static View.TelaCaixa.txtTotal;
import static View.TelaCaixa.txtquant;
import java.sql.Connection;
import java.sql.DriverManager; 
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;  // Importando Statement de java.sql
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Gabriel
 */
public class funcoes_DAO {

    // Defina as credenciais de conexão com o banco de dados aqui
    private static final String url = "jdbc:mysql://localhost/caixamercado"; // Substitua pelo seu URL do banco
    private static final String username = "root";  // Substitua pelo seu usuário
    private static final String password = "";  // Substitua pela sua senha

    public static void consultar() {
        //inicio

        try {     // Iniciando o possível tratamento de erros
            // Declarando a variável código
            int codigo = Integer.valueOf(txtCod.getText()); // txtCod deve ser um campo de texto na tela

            // Chama a função de carregamento do driver, certifique-se de que ela existe
            Controller.ConexaoBanco.carregaDriver();

            try { // Tratamento de erro para a conexão
                // Declarando a variável de conexão con
                // e estabelecendo a conexão
                Connection con = null;  // Usando o tipo Connection de java.sql

                try {
                    con = DriverManager.getConnection(url, username, password);  // Conectando ao banco
                } catch (SQLException ex) {
                    Logger.getLogger(TelaCaixa.class.getName()).log(Level.SEVERE, null, ex);
                }

                // Declarando uma string com o comando MySQL para consulta
                String sql = "SELECT nome, preco FROM tb_produto WHERE id = " + codigo;

                // Criando variável que executará o comando da string SQL
                Statement stm = con.createStatement();  // Usando o Statement de java.sql

                try { // Tratamento de erro da consulta
                    // Criando variável que exibirá os resultados
                    // Executando o comando da string SQL na variável rs
                    ResultSet rs = stm.executeQuery(sql);

                    int i = 0; // Variável utilizada para saber se há dados cadastrados

                    while (rs.next()) {  // Criando variáveis que receberão os valores do banco de dados
                        String nomee = rs.getString("nome");
                        String prec = rs.getString("preco");

                        i++;

                        // Exibindo os resultados
                        prod_txt.setText(String.valueOf(nomee));
                        prec_txt.setText(String.valueOf(prec));
                    }

                    if (i == 0) { // Verificando se há dados cadastrados
                        JOptionPane.showMessageDialog(null, "Dado não cadastrado", "Resultado", -1);
                    }

                } catch (Exception ex) { // Consulta mal-sucedida
                    JOptionPane.showMessageDialog(null, "\nErro ao consultar!", "ERRO", 0);
                }

            } catch (SQLException ex) {
                // Conexão com o servidor mal-sucedida
                JOptionPane.showMessageDialog(null, "Erro ao conectar com o servidor", "ERRO!", 0);
            }

        } catch (NumberFormatException erro) {
            // Código fora do formato
            JOptionPane.showMessageDialog(null, "Digite o código corretamente", "ERRO", 0);
            txtCod.setText("");
        }

        // fim
    }

    public static void valor() {
        String nome = prod_txt.getText();
        String quanti = txtquant.getText();

        nome_t.append(nome + "\n");
        quan.append(quanti + "\n");

        double val1 = Double.parseDouble(prec_txt.getText());
        int val2 = Integer.parseInt(txtquant.getText());
        double valor = val1 * val2;

        txtPreco2.append(valor + "\n");
    }
    
  // Método para somar todos os valores no JTextArea (txtPreco2)
public static void somarValores() {
   // Método para somar todos os valores no JTextArea (txtPreco2)

    // Obtém o texto do JTextArea
    String text = txtPreco2.getText();

    // Separa as linhas do texto usando quebra de linha como delimitador
    String[] lines = text.split("\n");

    // Inicializa uma variável para somar os valores
    double total = 0.0;

    // Itera por cada linha e soma os valores
    for (String line : lines) {
        try {
            // Verifica se a linha não está vazia
            if (!line.trim().isEmpty()) {
                // Converte para double e soma ao total
                total += Double.parseDouble(line.trim());
            }
        } catch (NumberFormatException e) {
            // Se não for possível converter (caso algum valor não seja numérico), ignora
            System.out.println("Erro ao converter o valor: " + line);
        }
    }

    // Atualiza o texto no JTextArea (txtTotal) com o valor total calculado
    txtTotal.setText(String.format("%.2f", total));
}

;}
